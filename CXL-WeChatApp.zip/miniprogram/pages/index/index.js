// 获取全局应用程序实例对象
const app = getApp();

// 创建页面实例对象
Page({
  /**
   * 页面名称
   */
  name: "index",
  /**
   * 页面的初始数据
   */

  data: {



  },
  //http://150.158.82.105:8083/login
  //http://localhost:8083/login
  login: function (options) {
    wx.request({
      url: 'http://localhost:8084/commentQianZhi',
      method: "GET",
      data: {
        userId: 1,
        commentText:'这是测试7',
        token:'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9eyJhdWQiOiJjeGwiLCJleHAiOjE2NTMyMDc2NzQsImlhdCI6MTY1MzIwNDA3NzgicffIREiI-5gqUAF0EpHyQkCOQWff6Su7Fa5SSHg',
        commentCategoryClass:"求助"
      },
      success: function (res) {
       console.log(res)
      }
    })
  },
  register: function () {
    wx.showToast({
      title: '正在跳转',
      icon: 'loading',
      duration: 1500,
      mask: false,
      success: function () {
        setTimeout(function () {
          wx.navigateTo({
              url: '../register/register',
            }),
            wx.setNavigationBarTitle({
              title: '注册界面',
            })
        }, 2000);
      }
    })
  }

})