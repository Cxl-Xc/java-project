// page/add/add.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    fileList: [],
    title: '',
    text: ''
  },
  onChange(event) {
    // event.detail 为当前输入的值
    //console.log(event.detail);
    this.setData({
      title: event.detail.value
    });

  },
  onChange2(event) {
    // event.detail 为当前输入的值
    // console.log(event.detail.value);
    this.setData({
      text: event.detail.value
    });

  },

  afterRead(event) {
    for (let index = 0; index < event.detail.file.length; index++) {


      let info = {
        url: event.detail.file[index].url,
      }
      let lists = this.data.fileList
      console.log(info)
      lists.push(info)
      this.setData({
        fileList: lists
      })



    }

  },
  delPic(event) {
    let lists = this.data.fileList
    lists.splice(event.detail.index, 1)
    this.setData({
      fileList: lists
    })
  },
  fabiao() {

    // wx.request({
    //   url: 'http://150.158.82.105:8083/login',
    //   method: "POST",
    //   data: {
    //     username: options.detail.value.username,
    //     password: options.detail.value.password
    //   },
    let that = this
    for (let index = 0; index < this.data.fileList.length; index++) {
      wx.request({
        url: 'https://www.xiaochenya.xyz:8085/commentQianZhi', // 仅为示例，非真实的接口地址
        method: "POST",
        // filePath: this.data.fileList[index].url,
        // name: 'files',
        formData: {
          userId: '1',
          commentText:'这是测试7',
          token:'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJjeGwiLCJleHAiOjE2NTMyMDc2NzQsImlhdCI6MTY1MzIwNDA3NH0.4zgicffIREiI-5gqUAF0EpHyQkCOQWff6Su7Fa5SSHg',
          commentCategoryClass:"求助"
          // userName: app.globalData.user.username,
          // addTitle: that.data.title,
          // addText: that.data.text,
       
          // commentText:"1",
          // token:"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJjeGwiLCJleHAiOjE2NTMxMjUzODAsImlhdCI6MTY1MzEyMTc4MH0.nALX0M5OoS4SUamXK5M1c7l0W0ZM2pNYdSnrWw5PdhU",
          // commentCategoryClass:"经验"

        },

        success: (res) => {
          const testjson = JSON.parse(res.data)
          if (testjson.status == 'SUCCESS') {
            wx.showToast({
              title: testjson.message,
              icon: 'loading',
              duration: 1500,
              mask: false,
              success: function () {
                setTimeout(function () {
                  wx.switchTab({
                      url: '../home/home',
                    }),
                    wx.setNavigationBarTitle({
                      title: app.globalData.user.username + '的用户页面',
                    })
                }, 2000);
              }
            })


          }
          this.setData({
            fileList: [],
            title: '',
            text: ''
          })
        },
      });
    }


    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})