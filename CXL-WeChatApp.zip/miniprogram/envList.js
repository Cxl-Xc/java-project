const envList = [{"envId":"cloud1-7g7nqd7a723b6386","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}